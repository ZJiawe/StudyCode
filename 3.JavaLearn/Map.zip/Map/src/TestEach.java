import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public class TestEach {
	public static void main(String args[]) {
		hashMap();
		System.out.println("++++++++++++++++++++++++++++++++");
		hashtable();
		System.out.println("++++++++++++++++++++++++++++++++");
		LinkedHashMap();
		System.out.println("++++++++++++++++++++++++++++++++");
		TreeMap();
	}
	
	//HashMap
	public static void hashMap() {
		int n = 100000;
		System.out.println("============HashMap=============");
		long startTime = System.nanoTime();
		HashMap<Integer,String> hm =new  HashMap<Integer,String>();
		for(int i=0;i<n;i++) {
			hm.put(i, "aaa");
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");	
		traverseByEntry(hm);
		traverseByKeySet(hm);
	}
	
	//Hashtable
	public static void hashtable() {
		int n = 100000;
		System.out.println("============hashtable=============");
		long startTime = System.nanoTime();
		Hashtable<Integer,String> ht =new  Hashtable<Integer,String>();
		for(int i=0;i<n;i++) {
			ht.put(i, "aaa");
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");	
		traverseByEntry(ht);
		traverseByKeySet(ht);
	}
	
	//LinkedHashMap
	public static void LinkedHashMap() {
		int n = 100000;
		System.out.println("============LinkedHashMap=============");
		long startTime = System.nanoTime();
		LinkedHashMap<Integer,String> hm = new  LinkedHashMap<Integer,String>();
		for(int i=0;i<n;i++) {
			hm.put(i, "aaa");
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");	
		traverseByEntry(hm);
		traverseByKeySet(hm);
	}
	
	//TreeMap
	public static void TreeMap() {
		int n = 100000;
		System.out.println("============TreeMap=============");
		long startTime = System.nanoTime();
		TreeMap<Integer,String> hm =new  TreeMap<Integer,String>();
		for(int i=0;i<n;i++) {
			hm.put(i, "aaa");
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");	
		traverseByEntry(hm);
		traverseByKeySet(hm);

	}
	
	public static void traverseByEntry(Map<Integer,String> ht)
	{
		long startTime = System.nanoTime();
		System.out.println("============Entry����������==============");
		Integer key;
		String value;
		Iterator<Entry<Integer, String>> iter = ht.entrySet().iterator();
		while(iter.hasNext()) {
		    Map.Entry<Integer, String> entry = iter.next();
		    // ��ȡkey
		    key = entry.getKey();
		    // ��ȡvalue
		    value = entry.getValue();
		    //System.out.println("Key:" + key + ", Value:" + value);
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");
	}
	
	public static void traverseByKeySet(Map<Integer,String> ht)
	{
		long startTime = System.nanoTime();
		System.out.println("============KeySet����������=============="); 
		Integer key;
		String value;
		Iterator<Integer> iter = ht.keySet().iterator();
		while(iter.hasNext()) {
		    key = iter.next();		    
		    // ��ȡvalue
		    value = ht.get(key);
		    //System.out.println("Key:" + key + ", Value:" + value);
		}
		long endTime = System.nanoTime();
	    long duration = endTime - startTime;
	    System.out.println(duration + "����");
	}
	
	
	
	
}
