import java.util.Date;

public class DateTest {

	public static void main(String[] args) {
		Date d = new Date();
		System.out.println(d);
		System.out.println(d.getTime()); 
		//the number of milliseconds since 1970.1.1 00:00:00 

	}

}
