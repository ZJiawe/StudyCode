
class Cat
{
	private int size;
	
	public Cat(int size)
	{
		this.size = size;
	}
}