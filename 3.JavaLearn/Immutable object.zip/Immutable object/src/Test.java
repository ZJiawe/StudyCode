
public class Test {

	public static void chang(StringBuffer a) {
		a.replace(0, a.length(), "");
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer b = new StringBuffer("asdf");
		System.out.println(b);
		Test.chang(b);
		System.out.println(b);
	}

}
